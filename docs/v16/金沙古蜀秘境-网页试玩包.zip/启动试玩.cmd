@echo off
setlocal
cd /d "%~dp0"
where node.exe >nul 2>nul
if not errorlevel 1 goto node
where py.exe >nul 2>nul
if not errorlevel 1 goto pythonlauncher
where python.exe >nul 2>nul
if not errorlevel 1 goto python
echo This local preview requires Node.js 18+ or Python 3.
echo For browser-only play, use the publisher's hosted URL.
pause
exit /b 1
:node
node.exe local-server.cjs
goto done
:pythonlauncher
py.exe -3 -c "import sys;assert sys.version_info.major==3" >nul 2>nul
if errorlevel 1 goto python
set "python_command=py.exe -3"
goto serve_python
:python
python.exe -c "import sys;assert sys.version_info.major==3" >nul 2>nul
if errorlevel 1 goto done
set "python_command=python.exe"
:serve_python
%python_command% -c "from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler;from functools import partial;import webbrowser;s=ThreadingHTTPServer(('127.0.0.1',5197),partial(SimpleHTTPRequestHandler,directory='site'));print('http://127.0.0.1:5197/',flush=True);webbrowser.open('http://127.0.0.1:5197/');s.serve_forever()"
:done
if errorlevel 1 pause
